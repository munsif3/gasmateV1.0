export * from './my-teams/my-teams.page';
export * from './tournaments/tournaments.page';
export * from './game/game.page';
export * from './team-detail/team-detail.page';
export * from './teams/teams.page';
export * from './standings/standings.page';
export * from './team-home/team-home.page';
export * from './map/map.page';